package com.sr.dbConnection;

import java.sql.Connection;
import java.sql.DriverManager;
public class Connection1 {

	public static Connection getConnection() throws Exception
	{

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mvc_db","root","root");
		return con;

	}

}
