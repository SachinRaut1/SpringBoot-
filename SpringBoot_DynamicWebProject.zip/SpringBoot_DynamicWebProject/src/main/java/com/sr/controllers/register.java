package com.sr.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import com.sr.dbConnection.Connection1;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/regForm")
public class register extends HttpServlet {




	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		resp.setContentType("text/html");

		String myname = req.getParameter("name");
		String myemail = req.getParameter("email");
		String mypasswd = req.getParameter("passwd");
		String mycity = req.getParameter("city");

		try {
			Connection con = Connection1.getConnection();
			String insert_sql_query = "INSERT INTO register VALUES(?,?,?,?)";

			PreparedStatement ps = con.prepareStatement(insert_sql_query);

			ps.setString(1, myname);
			ps.setString(2, myemail);
			ps.setString(3, mypasswd);
			ps.setString(4, mycity);

			int count = ps.executeUpdate();
			if (count >0) {
				out.println("<h3 style='color:green'>Registerd Successfully</h3>");

				RequestDispatcher rd = req.getRequestDispatcher("/login.html");
				rd.include(req, resp);
			}
			else
			{
				out.println("<h3 style='color:red'>user not Registerd due to some error</h3>");

				RequestDispatcher rd = req.getRequestDispatcher("/register.html");
				rd.include(req, resp);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

	}

}
