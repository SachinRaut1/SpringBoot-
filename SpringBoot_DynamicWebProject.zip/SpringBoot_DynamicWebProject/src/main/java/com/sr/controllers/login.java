package com.sr.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.sr.beanModel.User;
import com.sr.dbConnection.Connection1;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/loginForm")
public class login extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		resp.setContentType("text/html");

		String myemail = req.getParameter("email");
		String mypasswd = req.getParameter("passwd");

		try
		{
			Connection con = Connection1.getConnection();
			String Select_query="SELECT * FROM register where email=? AND passwd=?";

		PreparedStatement ps = con.prepareStatement(Select_query);
		ps.setString(1, myemail);
		ps.setString(2, mypasswd);

		ResultSet rs = ps.executeQuery();
		if(rs.next())
		{
			User usr=new User();
			usr.setName(rs.getString("name"));
			usr.setEmail(rs.getString("email"));
			usr.setCity(rs.getNString("city"));

			HttpSession session = req.getSession();
			session.setAttribute("session_user", usr);

			RequestDispatcher rd = req.getRequestDispatcher("./profile.jsp");
			rd.forward(req, resp);
		}
		else
		{

			out.println("<h3 style='color:red'>email and passwd are not match</h3>");

			RequestDispatcher rd = req.getRequestDispatcher("/login.html");
			rd.include(req, resp);
		}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

}



