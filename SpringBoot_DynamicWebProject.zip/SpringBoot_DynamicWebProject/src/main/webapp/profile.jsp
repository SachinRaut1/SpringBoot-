<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%@ page import="com.sr.beanModel.User" %>

<%User usr=(User) session.getAttribute("session_user");%>

	<h2>welcome to the database</h2>
	
	<h3>Name:<%=usr.getName() %> </h3>
	<h3>email:<%=usr.getEmail() %> </h3>
	<h3>city:<%=usr.getCity() %> </h3>
<a href="logout">Logout</a>


</body>
</html>